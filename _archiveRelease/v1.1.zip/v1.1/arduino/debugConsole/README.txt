You can find this program under the C examples directory

https://github.com/kehribar/Little-Wire/blob/master/v1.1/computer_interface/C/examples/debugConsole.c