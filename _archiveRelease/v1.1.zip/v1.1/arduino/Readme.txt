
*HIGHLY* experimental printf style debugging over AVR-ISP cable support for Little Wire.


Put the LittleWire folder under the ...\arduino-1.0\libraries\ path

-- Updated for the V1.1 firmware.
-- More robust console output!