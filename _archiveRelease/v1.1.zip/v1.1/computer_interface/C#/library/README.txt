1 - Add 'LibUsbDotNet.dll' to your project references.
2 - Add 'littleWire.cs' file to your project.
3 - Add 'using littleWireLib;' line to head of your project file.
4 - You are ready to use!