Hi!

This is the 'beta' C# library for the V1.1 firrmware release

There isn't any examples 'yet'. If you implement any, please send me a pull request!

Also, if you find any bugs, open an issue ticket from the gitHub.

ihsan.
