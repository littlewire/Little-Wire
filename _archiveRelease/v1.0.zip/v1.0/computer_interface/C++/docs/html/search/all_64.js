var searchData=
[
  ['digitalread',['digitalRead',['../group__GPIO.html#ga203436de9031afe3e82412f6d2045fe1',1,'littleWire']]],
  ['digitalwrite',['digitalWrite',['../group__GPIO.html#ga896fb0c440930e3e7ea8ed39577338a2',1,'littleWire']]]
];
