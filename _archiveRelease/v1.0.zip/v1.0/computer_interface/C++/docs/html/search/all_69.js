var searchData=
[
  ['i2c_5fbegintransmission',['i2c_beginTransmission',['../group__I2C.html#ga54ec09723ddf46eb8a34851346270689',1,'littleWire']]],
  ['i2c_5fendtransmission',['i2c_endTransmission',['../group__I2C.html#gac0a74856bfaa7babff9d94fc437e6971',1,'littleWire']]],
  ['i2c_5finit',['i2c_init',['../group__I2C.html#ga45c2707d5c9e7bb34ef692ec93d41548',1,'littleWire']]],
  ['i2c_5frequestfrom',['i2c_requestFrom',['../group__I2C.html#gad5605b7ee59aaae635f4a5cb6f44d12c',1,'littleWire']]],
  ['i2c_5fsend',['i2c_send',['../group__I2C.html#ga9d3d4407ab4d6ed0ac1d55b017540507',1,'littleWire']]]
];
