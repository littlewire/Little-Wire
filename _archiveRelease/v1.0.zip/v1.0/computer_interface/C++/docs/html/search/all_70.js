var searchData=
[
  ['pinmode',['pinMode',['../group__GPIO.html#gaf657af6bcf549893b5fd7df1049dabc8',1,'littleWire']]],
  ['pwm_5finit',['pwm_init',['../group__PWM.html#gacf483e7e2f583aa03f3c04b7679f8154',1,'littleWire']]],
  ['pwm_5fstop',['pwm_stop',['../group__PWM.html#gae271ef531c63a6c4739ac0b74f6a9b32',1,'littleWire']]],
  ['pwm_5fupdatecompare',['pwm_updateCompare',['../group__PWM.html#ga49de16d3d4d1d12ff9be1e86fbdf4d77',1,'littleWire']]],
  ['pwm_5fupdateprescaler',['pwm_updatePrescaler',['../group__PWM.html#ga00985706f6aa20cad938832f6d3303d7',1,'littleWire']]]
];
