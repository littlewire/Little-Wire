var searchData=
[
  ['connect',['connect',['../classlittleWire.html#ab27313730210db2f7bf6e2f080433b57',1,'littleWire']]]
];
