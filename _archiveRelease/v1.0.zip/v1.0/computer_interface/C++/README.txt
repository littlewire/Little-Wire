Use MinGW Shell console for "making" the program in Windows.

You can also set up other developement environments like Dev-Cpp, Eclipse, Visual Studio.

Install libusb developement package for compiling example on Linux
	sudo apt-get install libusb-dev

In order get the examples working on Linux, open it with a root privileges. For example:
	sudo ./main
